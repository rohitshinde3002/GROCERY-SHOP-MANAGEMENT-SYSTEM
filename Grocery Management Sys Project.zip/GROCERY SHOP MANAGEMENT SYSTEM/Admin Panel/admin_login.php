<?php
include('../Connection/db_connection.php');
session_start(); // Use session_start() without the '@'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- logo -->
    <link rel="icon" href="../images/logo.jpg" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>
<style>
    .admin {
        width: 80%;
        height: 100%;
    }
</style>
<body>
    <div class="container-fluid m-3 p-0">
        <h2 class="text-center text-primary">Admin Login</h2>
        <hr class="text-primary">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-6 col-xl-5">
                <img src="./admin image/admin.webp" alt="admin registration" class="admin">
            </div>
            <div class="col-lg-6 col-xl-5">
                <form action="" method="post">
                    <div class="form-outline mb-4">
                        <label for="adminname" class="form-label">Username</label>
                        <input type="text" id="adminname" name="admin_name" placeholder="Enter Your Name" class="form-control" required="required" autocomplete="off">
                    </div>
                    <div class="form-outline mb-4">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" name="admin_password" placeholder="Enter Your Password" class="form-control" required="required" autocomplete="off">
                    </div>
                    <div class="form-outline mb-4">
                        <input type="checkbox" name="" id=""> Terms and Condition Accept
                    </div>
                    <div class="form-outline mb-4">
                        <input type="submit" value="Login" class="btn btn-primary" name="login">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

<?php
if (isset($_POST['login'])) {
    $admin_name = $_POST['admin_name'];
    $admin_password = $_POST['admin_password'];

    // Check if the connection is successful
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $con->prepare("SELECT * FROM admin_tbl WHERE admin_name = ?");
    $stmt->bind_param("s", $admin_name);
    $stmt->execute();
    $result_query = $stmt->get_result();
    
    // Check if a result was found
    if ($result_query->num_rows > 0) {
        $row_data = $result_query->fetch_assoc();

        // Verify the password using password_verify
       // if (password_verify($admin_password, $row_data['admin_password'])) {
            $_SESSION['admin_name'] = $admin_name;
            echo "<script>alert('Login Successfully')</script>";
            echo "<script>window.open('index.php','_self')</script>";
        } //else {
            echo "<script>alert('Invalid Credentials')</script>";
        }
     else {
        echo "<script>alert('No user found with that username')</script>";
    
    }

?>
